import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, FlatList, StyleSheet, Alert, ScrollView } from 'react-native';

export default function App() {
const [dishName, setDishName] = useState('');
const [description, setDescription] = useState('');
const [course, setCourse] = useState('Main');
const [price, setPrice] = useState('');
const [menuItems, setMenuItems] = useState([]);

const handleAddDish = () => {
if (!dishName.trim() || !description.trim() || !price.trim()) {
Alert.alert('Error', 'Please fill in all fields');
return;
}
if (isNaN(price)) {
Alert.alert('Error', 'Price must be a number');
return;
}

const newDish = {
id: Date.now().toString(),
dishName: dishName,
description: description,
course: course,
price: price,
};

setMenuItems([...menuItems, newDish]);
Alert.alert('Success', dishName + ' added to menu!');

setDishName('');
setDescription('');
setPrice('');
setCourse('Main');
};

return (
<ScrollView style={styles.container}>
{/* Header */}
<View style={styles.header}>
<Text style={styles.headerTitle}>My Menu</Text>
<Text style={styles.total}>Total Dishes: {menuItems.length}</Text>
</View>

{/* Form */}
<View style={styles.form}>
<Text style={styles.formTitle}>Add New Dish</Text>

<Text style={styles.label}>Dish Name:</Text>
<TextInput
style={styles.input}
value={dishName}
onChangeText={setDishName}
placeholder="e.g. Grilled Chicken Pizza"
/>

<Text style={styles.label}>Description:</Text>
<TextInput
style={[styles.input, { height: 70 }]}
value={description}
onChangeText={setDescription}
placeholder="e.g. Grilled chicken with herbs"
multiline
/>

<Text style={styles.label}>Course (Selected: {course}):</Text>
<View style={styles.courseRow}>
<TouchableOpacity onPress={() => setCourse('Starter')} style={[styles.courseBtn, course === 'Starter' && styles.active]}>
<Text style={course === 'Starter' ? styles.activeText : styles.btnText}>Starter</Text>
</TouchableOpacity>
<TouchableOpacity onPress={() => setCourse('Main')} style={[styles.courseBtn, course === 'Main' && styles.active]}>
<Text style={course === 'Main' ? styles.activeText : styles.btnText}>Main</Text>
</TouchableOpacity>
<TouchableOpacity onPress={() => setCourse('Dessert')} style={[styles.courseBtn, course === 'Dessert' && styles.active]}>
<Text style={course === 'Dessert' ? styles.activeText : styles.btnText}>Dessert</Text>
</TouchableOpacity>
</View>

<Text style={styles.label}>Price (R):</Text>
<TextInput
style={styles.input}
value={price}
onChangeText={setPrice}
placeholder="e.g. 120"
keyboardType="numeric"
/>

<TouchableOpacity style={styles.saveBtn} onPress={handleAddDish}>
<Text style={styles.saveText}>Save Dish</Text>
</TouchableOpacity>
</View>

{/* List */}
<View style={styles.listSection}>
<Text style={styles.listTitle}>Menu Items</Text>
{menuItems.length === 0 ? (
<Text style={styles.emptyText}>No menu items have been added yet.</Text>
) : (
<FlatList
data={menuItems}
scrollEnabled={false}
keyExtractor={(item) => item.id}
renderItem={({ item }) => (
<View style={styles.card}>
<Text style={styles.cardName}>{item.dishName} - R{item.price}</Text>
<Text style={styles.cardCourse}>{item.course}</Text>
<Text style={styles.cardDesc}>{item.description}</Text>
</View>
)}
/>
)}
</View>
</ScrollView>
);
}

const styles = StyleSheet.create({
container: { flex: 1, backgroundColor: '#F5F5F5' },
header: { backgroundColor: '#1B4332', padding: 20, paddingTop: 50, alignItems: 'center' },
headerTitle: { color: 'white', fontSize: 24, fontWeight: 'bold' },
total: { color: '#D8F3DC', marginTop: 5, fontSize: 14 },
form: { backgroundColor: 'white', margin: 15, padding: 15, borderRadius: 10, elevation: 2 },
formTitle: { fontSize: 18, fontWeight: 'bold', marginBottom: 10 },
label: { fontWeight: '600', marginTop: 12, marginBottom: 5 },
input: { backgroundColor: '#FAFAFA', borderWidth: 1, borderColor: '#DDD', borderRadius: 6, padding: 10 },
courseRow: { flexDirection: 'row', gap: 8 },
courseBtn: { flex: 1, borderWidth: 1, borderColor: '#CCC', padding: 10, borderRadius: 6, alignItems: 'center' },
active: { backgroundColor: '#1B4332', borderColor: '#1B4332' },
btnText: { color: '#333' },
activeText: { color: 'white', fontWeight: 'bold' },
saveBtn: { backgroundColor: '#40916C', padding: 14, borderRadius: 8, alignItems: 'center', marginTop: 20 },
saveText: { color: 'white', fontWeight: 'bold', fontSize: 16 },
listSection: { padding: 15 },
listTitle: { fontWeight: 'bold', fontSize: 16, marginBottom: 10 },
emptyText: { fontStyle: 'italic', color: '#888', textAlign: 'center', marginTop: 20 },
card: { backgroundColor: 'white', padding: 12, borderRadius: 8, marginBottom: 8, borderLeftWidth: 4, borderLeftColor: '#2D6A4F' },
cardName: { fontWeight: 'bold', fontSize: 15 },
cardCourse: { fontSize: 12, color: '#2D6A4F', fontWeight: '600' },
cardDesc: { fontSize: 13, color: '#555', marginTop: 2 },
});