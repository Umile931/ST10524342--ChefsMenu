import React, { useState } from 'react';
import { StyleSheet, Text, View, TextInput, TouchableOpacity, FlatList, ScrollView } from 'react-native';

export default function App() {
const [menuItems, setMenuItems] = useState([]);
const [dishName, setDishName] = useState('');
const [description, setDescription] = useState('');
const [course, setCourse] = useState('Main');
const [price, setPrice] = useState('');
const [editingId, setEditingId] = useState(null);
const [searchQuery, setSearchQuery] = useState('');
const [filterCourse, setFilterCourse] = useState('All');

// Reusable function - Add / Update (Enhancement 4)
const handleSave = () => {
if (!dishName.trim() || !price.trim()) {
alert('Please enter dish name and price');
return;
}
const priceNum = parseFloat(price);
if (isNaN(priceNum) || priceNum <= 0) {
alert('Price must be a valid number > 0');
return;
}

if (editingId) {
// Update existing
setMenuItems(menuItems.map(item =>
item.id === editingId ? { ...item, name: dishName, description, course, price: priceNum } : item
));
setEditingId(null);
} else {
// Add new
const newItem = {
id: Date.now().toString(),
name: dishName,
description,
course,
price: priceNum,
};
setMenuItems([...menuItems, newItem]);
}
clearForm();
};

const clearForm = () => {
setDishName(''); setDescription(''); setCourse('Main'); setPrice(''); setEditingId(null);
};

const handleEdit = (item) => {
setDishName(item.name);
setDescription(item.description);
setCourse(item.course);
setPrice(item.price.toString());
setEditingId(item.id);
};

const handleDelete = (id) => {
setMenuItems(menuItems.filter(item => item.id !== id));
};

// Search and Filter Logic (Requirement 2)
const filteredItems = menuItems.filter(item => {
const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase());
const matchesFilter = filterCourse === 'All' || item.course === filterCourse;
return matchesSearch && matchesFilter;
});

// Statistics Logic (Requirement 3)
const totalItems = menuItems.length;
const averagePrice = totalItems > 0 ? (menuItems.reduce((sum, i) => sum + i.price, 0) / totalItems).toFixed(2) : 0;
const starterCount = menuItems.filter(i => i.course === 'Starter').length;
const mainCount = menuItems.filter(i => i.course === 'Main').length;
const dessertCount = menuItems.filter(i => i.course === 'Dessert').length;

// Reusable Component (Enhancement 4)
const CourseButton = ({ label }) => (
<TouchableOpacity
style={[styles.courseBtn, course === label && styles.courseBtnActive]}
onPress={() => setCourse(label)}>
<Text style={styles.courseBtnText}>{label}</Text>
</TouchableOpacity>
);

return (
<ScrollView style={styles.container}>
<Text style={styles.title}>Chef's Menu Manager - Final POE</Text>

{/* STATISTICS SECTION */}
<View style={styles.statsBox}>
<Text style={styles.sectionTitle}>Menu Statistics</Text>
<Text>Total Items: {totalItems}</Text>
<Text>Average Price: R{averagePrice}</Text>
<Text>Starter: {starterCount} | Main: {mainCount} | Dessert: {dessertCount}</Text>
</View>

{/* ADD / EDIT FORM */}
<View style={styles.formBox}>
<Text style={styles.sectionTitle}>{editingId ? 'Edit Item' : 'Add New Item'}</Text>
<TextInput style={styles.input} placeholder="Dish Name" value={dishName} onChangeText={setDishName} />
<TextInput style={styles.input} placeholder="Description" value={description} onChangeText={setDescription} />
<View style={styles.row}>
<CourseButton label="Starter" />
<CourseButton label="Main" />
<CourseButton label="Dessert" />
</View>
<TextInput style={styles.input} placeholder="Price (R)" value={price} onChangeText={setPrice} keyboardType="numeric" />
<TouchableOpacity style={styles.saveBtn} onPress={handleSave}>
<Text style={styles.btnText}>{editingId ? 'Update Item' : 'Add to Menu'}</Text>
</TouchableOpacity>
{editingId && (
<TouchableOpacity style={styles.cancelBtn} onPress={clearForm}>
<Text style={styles.btnText}>Cancel Edit</Text>
</TouchableOpacity>
)}
</View>

{/* SEARCH AND FILTER */}
<View style={styles.searchBox}>
<TextInput style={styles.input} placeholder="Search by name..." value={searchQuery} onChangeText={setSearchQuery} />
<View style={styles.row}>
{['All', 'Starter', 'Main', 'Dessert'].map(f => (
<TouchableOpacity key={f} style={[styles.filterBtn, filterCourse === f && styles.filterActive]} onPress={() => setFilterCourse(f)}>
<Text>{f}</Text>
</TouchableOpacity>
))}
</View>
<TouchableOpacity onPress={() => {setSearchQuery(''); setFilterCourse('All');}}>
<Text style={styles.clearText}>Clear Search & Filter - Show All</Text>
</TouchableOpacity>
</View>

{/* MENU LIST */}
<Text style={styles.sectionTitle}>Menu List ({filteredItems.length})</Text>
<FlatList
data={filteredItems}
keyExtractor={item => item.id}
scrollEnabled={false}
renderItem={({ item }) => (
<View style={styles.itemCard}>
<Text style={styles.itemName}>{item.name} - R{item.price}</Text>
<Text>{item.course} | {item.description}</Text>
<View style={styles.row}>
<TouchableOpacity style={styles.editBtn} onPress={() => handleEdit(item)}><Text style={styles.btnText}>Edit</Text></TouchableOpacity>
<TouchableOpacity style={styles.deleteBtn} onPress={() => handleDelete(item.id)}><Text style={styles.btnText}>Delete</Text></TouchableOpacity>
</View>
</View>
)}
/>
</ScrollView>
);
}

const styles = StyleSheet.create({
container: { flex: 1, padding: 15, backgroundColor: '#f5f5f5', marginTop: 30 },
title: { fontSize: 22, fontWeight: 'bold', textAlign: 'center', marginBottom: 10 },
sectionTitle: { fontSize: 16, fontWeight: 'bold', marginVertical: 8 },
statsBox: { backgroundColor: '#fff', padding: 15, borderRadius: 10, marginBottom: 10, elevation: 2 },
formBox: { backgroundColor: '#fff', padding: 15, borderRadius: 10, marginBottom: 10 },
searchBox: { backgroundColor: '#e3f2fd', padding: 15, borderRadius: 10, marginBottom: 10 },
input: { borderWidth: 1, borderColor: '#ccc', borderRadius: 8, padding: 10, marginVertical: 5, backgroundColor: '#fff' },
row: { flexDirection: 'row', justifyContent: 'space-around', marginVertical: 5 },
courseBtn: { padding: 8, borderWidth: 1, borderRadius: 5, minWidth: 80, alignItems: 'center' },
courseBtnActive: { backgroundColor: '#ffcc80' },
courseBtnText: { fontWeight: 'bold' },
saveBtn: { backgroundColor: '#4caf50', padding: 12, borderRadius: 8, alignItems: 'center', marginTop: 10 },
cancelBtn: { backgroundColor: '#9e9e9e', padding: 12, borderRadius: 8, alignItems: 'center', marginTop: 5 },
filterBtn: { padding: 8, borderWidth: 1, borderRadius: 5, minWidth: 60, alignItems: 'center' },
filterActive: { backgroundColor: '#90caf9' },
clearText: { color: 'blue', textAlign: 'center', marginTop: 10, textDecorationLine: 'underline' },
itemCard: { backgroundColor: '#fff', padding: 12, borderRadius: 8, marginVertical: 5, elevation: 1 },
itemName: { fontWeight: 'bold', fontSize: 15 },
editBtn: { backgroundColor: '#ff9800', padding: 8, borderRadius: 5, marginRight: 10, marginTop: 5, minWidth: 60, alignItems: 'center' },
deleteBtn: { backgroundColor: '#f44336', padding: 8, borderRadius: 5, marginTop: 5, minWidth: 60, alignItems: 'center' },
btnText: { color: '#fff', fontWeight: 'bold' },
});